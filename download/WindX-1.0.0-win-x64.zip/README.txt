﻿WindX 1.0 - a Dynamic Island for Windows
=========================================

HOW TO INSTALL
1. Right-click the downloaded zip and choose "Extract All...", then press Extract.
2. Open the extracted folder and double-click WindX.exe.
3. If Windows shows "Windows protected your PC", click "More info", then "Run anyway".
   (WindX is not code-signed yet. You can check the zip against the SHA-256 on the website.)
4. The island appears at the top of your screen with a short intro.

USING IT
- Click the island to open it. Move away or click again to close it.
- Scroll on the island to change the volume.
- Right-click the island (or double-click the tray icon) for Settings:
  themes, effects, timer and reminders, sounds, hanging note, and "Start with Windows".

LITE VERSION ONLY
The lite download needs the free Microsoft .NET 10 Desktop Runtime:
https://dotnet.microsoft.com/download/dotnet/10.0  (choose ".NET Desktop Runtime", x64)

UNINSTALL
Right-click the island > Settings > Quit WindX, then delete the folder.
To also remove your settings, delete %AppData%\WindX.

Website: https://getwindx.netlify.app   Privacy: https://getwindx.netlify.app/privacy.html
